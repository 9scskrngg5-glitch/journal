# Trading Journal

Journal de trading avec AI coaching, Monte Carlo risk engine, et détection de régime de marché.

---

## Architecture

```
src/
├── App.jsx                     ← Orchestrateur principal (UI seulement, ~100 lignes)
│
├── hooks/
│   ├── useTrades.js            ← State + actions pour les trades (persistance, stats, derived)
│   └── useTasks.js             ← State + actions pour les tâches
│
├── components/
│   ├── Dashboard.jsx           ← Tab dashboard (stats, equity curve, AI coach)
│   ├── TradesTab.jsx           ← Tab trades (liste, filtres, formulaire add/edit)
│   ├── TasksTab.jsx            ← Tab tâches
│   ├── SettingsTab.jsx         ← Tab settings (import/export/reset)
│   ├── TradeForm.jsx           ← Formulaire réutilisable (add + edit)
│   ├── TradeRow.jsx            ← Ligne individuelle d'un trade
│   ├── StatCard.jsx            ← Carte de stat
│   └── CustomTooltip.jsx       ← Tooltip pour le graphe recharts
│
├── lib/
│   ├── trading.js              ← Fonctions pures : calcRR, computeStats, monteCarlo…
│   ├── trading.test.js         ← Tests unitaires (vitest)
│   ├── ai.js                   ← Appel direct à l'API Anthropic
│   └── storage.js              ← Abstraction window.storage
│
└── types/
    └── index.js                ← JSDoc typedefs (Trade, Task, Stats, Regime…)
```

---

## Stack

- **React** (hooks, pas de librairie de state externe)
- **recharts** pour la courbe d'équité
- **window.storage** pour la persistance (API native des artifacts Claude)
- **Anthropic API** (`claude-sonnet-4-20250514`) pour l'AI coach

---

## Installation & démarrage

```bash
npm install
npm run dev       # dev server → http://localhost:5173
npm run build     # build de production → dist/
npm run preview   # preview du build
```

## Lancer les tests

```bash
npm run test        # watch mode
npm run test:run    # single run (CI)
npm run test:ui     # UI interactive
```

## Lint

```bash
npm run lint
```

---

## Fonctionnalités

| Feature | Description |
|---|---|
| Stats complètes | Win rate, PnL, expectancy, profit factor, max drawdown, win streak |
| Courbe d'équité | Area chart cumulatif de tous les trades fermés |
| Détection de régime | TRENDING_UP / DISTRIBUTION / SIDEWAYS / CHAOTIC (basé sur 20 derniers trades) |
| Monte Carlo | 400 simulations, 100 trades, calcul du % de ruine et drawdown moyen |
| AI Coach | Analyse des 20 derniers trades via claude-sonnet — feedback actionnable |
| Flags automatiques | RR < 1, Pas de SL, Revenge trade, Confiance faible |
| Filtres par pair | Filtrage de la liste de trades par instrument |
| Edition | Modal d'édition de trade avec recalcul automatique du RR |
| Import / Export | JSON complet (trades + tâches) |

---

## Notes

- Toutes les fonctions de calcul (`computeStats`, `monteCarlo`, `detectRegime`, etc.) sont des **fonctions pures** dans `lib/trading.js` — facilement testables et réutilisables.
- Le composant `App.jsx` ne contient **aucune logique métier** — il orchestre uniquement les hooks et passe les props aux tabs.
- `TradeForm` est réutilisé pour l'ajout ET l'édition, avec les mêmes validations.
