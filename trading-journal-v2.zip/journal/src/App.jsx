import { useState } from "react";
import { useTrades } from "./hooks/useTrades";
import { useTasks } from "./hooks/useTasks";
import { Dashboard } from "./components/Dashboard";
import { TradesTab } from "./components/TradesTab";
import { TasksTab } from "./components/TasksTab";
import { SettingsTab } from "./components/SettingsTab";

const TABS = ["dashboard", "trades", "tasks", "settings"];

export default function App() {
  const [tab, setTab] = useState("dashboard");

  const {
    trades,
    loaded,
    orderedTrades,
    orderedTradesDesc,
    equity,
    stats,
    regime,
    mc,
    pairs,
    addTrade,
    saveTrade,
    deleteTrade,
    importTrades,
    EMPTY_FORM,
  } = useTrades();

  const { tasks, addTask, toggleTask, deleteTask, clearDone, replaceTasks } = useTasks();

  const handleImport = async (payload) => {
    const result = await importTrades(payload);
    if (!result.error && result.tasks) await replaceTasks(result.tasks);
    return result;
  };

  const handleReset = async () => {
    await importTrades({ trades: [], tasks: [] });
    await replaceTasks([]);
  };

  if (!loaded) {
    return (
      <div
        style={{
          background: "#06080f",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#1e2235",
          fontFamily: "'DM Mono', monospace",
          fontSize: 13,
          letterSpacing: "0.1em",
        }}
      >
        chargement…
      </div>
    );
  }

  return (
    <div
      style={{
        background: "#06080f",
        minHeight: "100vh",
        color: "#dde1f5",
        fontFamily: "'DM Sans', sans-serif",
        maxWidth: 920,
        margin: "0 auto",
        padding: "28px 22px 72px",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:ital,wght@0,400;0,500;0,600;1,400&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        input, textarea { outline: none; }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #181b2e; border-radius: 4px; }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: none; }
        }
        .fade-in { animation: fadeIn 0.25s ease forwards; }
        @keyframes pulse {
          0%,100% { opacity: 1; }
          50%      { opacity: 0.3; }
        }
        .pulse { animation: pulse 1.6s ease infinite; }
      `}</style>

      {/* ── Header ── */}
      <header
        style={{
          display: "flex",
          alignItems: "flex-end",
          justifyContent: "space-between",
          marginBottom: 32,
        }}
      >
        <div>
          <div
            style={{
              fontSize: 10,
              color: "#1e2235",
              letterSpacing: "0.22em",
              textTransform: "uppercase",
              fontFamily: "'DM Mono', monospace",
              marginBottom: 5,
            }}
          >
            Trading Journal
          </div>
          <h1
            style={{
              fontSize: 30,
              fontWeight: 800,
              fontFamily: "'Syne', sans-serif",
              margin: 0,
              letterSpacing: "-0.025em",
              lineHeight: 1,
            }}
          >
            {stats ? (
              <span
                style={{ color: Number(stats.totalPnL) >= 0 ? "#00e5a0" : "#ff4d6d" }}
              >
                {Number(stats.totalPnL) >= 0 ? "+" : ""}
                {stats.totalPnL}$
              </span>
            ) : (
              <span style={{ color: "#1e2235" }}>—</span>
            )}
          </h1>
        </div>

        <nav style={{ display: "flex", gap: 5 }}>
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                padding: "7px 15px",
                borderRadius: 9,
                border: "1px solid",
                borderColor: tab === t ? "rgba(0,229,160,0.3)" : "#13162a",
                background:
                  tab === t ? "rgba(0,229,160,0.06)" : "transparent",
                color: tab === t ? "#00e5a0" : "#2d3352",
                cursor: "pointer",
                fontSize: 11,
                fontWeight: 600,
                fontFamily: "'DM Mono', monospace",
                letterSpacing: "0.06em",
                textTransform: "uppercase",
                transition: "all 0.18s",
              }}
              onMouseEnter={(e) => {
                if (tab !== t) e.currentTarget.style.color = "#4a5480";
              }}
              onMouseLeave={(e) => {
                if (tab !== t) e.currentTarget.style.color = "#2d3352";
              }}
            >
              {t}
            </button>
          ))}
        </nav>
      </header>

      {/* ── Tab content ── */}
      {tab === "dashboard" && (
        <Dashboard
          stats={stats}
          equity={equity}
          regime={regime}
          mc={mc}
          orderedTrades={orderedTrades}
        />
      )}

      {tab === "trades" && (
        <TradesTab
          trades={orderedTradesDesc}
          pairs={pairs}
          onAdd={addTrade}
          onSave={saveTrade}
          onDelete={deleteTrade}
          emptyForm={EMPTY_FORM}
        />
      )}

      {tab === "tasks" && (
        <TasksTab
          tasks={tasks}
          onAdd={addTask}
          onToggle={toggleTask}
          onDelete={deleteTask}
          onClearDone={clearDone}
        />
      )}

      {tab === "settings" && (
        <SettingsTab
          trades={trades}
          tasks={tasks}
          onImport={handleImport}
          onReset={handleReset}
        />
      )}
    </div>
  );
}
