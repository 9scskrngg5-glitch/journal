import { useState } from "react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  CartesianGrid, ResponsiveContainer,
} from "recharts";
import { StatCard } from "./StatCard";
import { CustomTooltip } from "./CustomTooltip";
import { REGIME_META } from "../lib/trading";
import { fetchAIInsight } from "../lib/ai";

/**
 * @param {{
 *   stats: import('../types').Stats|null,
 *   equity: {i:number,eq:number}[],
 *   regime: import('../types').Regime|null,
 *   mc: import('../types').MonteCarloResult|null,
 *   orderedTrades: import('../types').Trade[],
 * }} props
 */
export const Dashboard = ({ stats, equity, regime, mc, orderedTrades }) => {
  const [aiInsight, setAiInsight] = useState("");
  const [aiError, setAiError] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const runAI = async () => {
    setAiLoading(true);
    setAiError("");
    setAiInsight("");
    try {
      const text = await fetchAIInsight(orderedTrades);
      setAiInsight(text);
    } catch (e) {
      setAiError("Erreur IA : " + (e?.message || String(e)));
    } finally {
      setAiLoading(false);
    }
  };

  const closedCount = orderedTrades.filter((t) => t.result !== "").length;

  return (
    <div className="fade-in">
      {/* Stats grid */}
      {stats ? (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 10,
            marginBottom: 16,
          }}
        >
          <StatCard
            label="Win Rate"
            value={`${stats.winRate}%`}
            color={Number(stats.winRate) >= 50 ? "#00e5a0" : "#ff4d6d"}
            sub={`${stats.total} trades`}
          />
          <StatCard
            label="PnL Total"
            value={`${Number(stats.totalPnL) >= 0 ? "+" : ""}${stats.totalPnL}$`}
            color={Number(stats.totalPnL) >= 0 ? "#00e5a0" : "#ff4d6d"}
          />
          <StatCard
            label="Expectancy"
            value={`${Number(stats.expectancy) >= 0 ? "+" : ""}${stats.expectancy}$`}
            color={Number(stats.expectancy) >= 0 ? "#00e5a0" : "#ff4d6d"}
            sub="par trade"
          />
          <StatCard
            label="Profit Factor"
            value={stats.profitFactor}
            color={
              Number(stats.profitFactor) >= 1.5
                ? "#00e5a0"
                : Number(stats.profitFactor) >= 1
                ? "#f5a623"
                : "#ff4d6d"
            }
            sub="≥ 1.5 = bon"
          />
          <StatCard label="Max Drawdown" value={`-${stats.maxDD}$`} color="#ff4d6d" sub="pic → creux" />
          <StatCard
            label="Best Trade"
            value={`+${stats.bestTrade}$`}
            color="#00e5a0"
            sub={`Pire: ${stats.worstTrade}$`}
          />
          <StatCard
            label="Win Streak"
            value={`${stats.streak}🔥`}
            sub={`Avg win: +${stats.avgWin}$`}
          />
          <StatCard
            label="Avg Loss"
            value={`-${stats.avgLoss}$`}
            color="#ff4d6d"
            sub={`Avg win: +${stats.avgWin}$`}
          />
          <StatCard
            label="Regime"
            value={regime ? REGIME_META[regime]?.label : "—"}
            color={regime ? REGIME_META[regime]?.color : "#a0a8c8"}
            sub={regime ? REGIME_META[regime]?.hint : "Basé sur 10 trades fermés"}
          />
          <StatCard
            label="Monte Carlo"
            value={mc ? `Ruin ${mc.ruinPct}%` : "—"}
            color={
              mc
                ? Number(mc.ruinPct) <= 10
                  ? "#00e5a0"
                  : Number(mc.ruinPct) <= 25
                  ? "#f5a623"
                  : "#ff4d6d"
                : "#a0a8c8"
            }
            sub={mc ? `DD moyen: ${mc.avgDD}$` : "400 sims, 100 trades max"}
          />
        </div>
      ) : (
        <div
          style={{
            background: "#0a0d18",
            border: "1px dashed #181b2e",
            borderRadius: 16,
            padding: 24,
            marginBottom: 16,
            color: "#252840",
            textAlign: "center",
            fontSize: 13,
            fontFamily: "'DM Mono', monospace",
          }}
        >
          Ajoute des trades pour voir tes stats
        </div>
      )}

      {/* Equity curve */}
      <div
        style={{
          background: "linear-gradient(135deg, #0a0d18 0%, #080a14 100%)",
          border: "1px solid #13162a",
          borderRadius: 16,
          padding: "20px 16px 10px",
          marginBottom: 16,
        }}
      >
        <div
          style={{
            fontSize: 10,
            color: "#3a4060",
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            fontFamily: "'DM Mono', monospace",
            marginBottom: 14,
          }}
        >
          Courbe d'équité
        </div>
        {equity.length > 1 ? (
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={equity}>
              <defs>
                <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00e5a0" stopOpacity={0.12} />
                  <stop offset="95%" stopColor="#00e5a0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#0e1120" />
              <XAxis dataKey="i" tick={{ fontSize: 10, fill: "#252840" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#252840" }} axisLine={false} tickLine={false} width={48} />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="eq"
                stroke="#00e5a0"
                strokeWidth={1.5}
                fill="url(#eqGrad)"
                dot={false}
                activeDot={{ r: 4, fill: "#00e5a0", strokeWidth: 0 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div
            style={{
              height: 160,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#1e2235",
              fontSize: 12,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            Pas assez de données
          </div>
        )}
      </div>

      {/* AI Coach */}
      <div
        style={{
          background: "linear-gradient(135deg, #0a0d18 0%, #080a14 100%)",
          border: "1px solid #13162a",
          borderRadius: 16,
          padding: 22,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: 14,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 10,
                color: "#3a4060",
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                fontFamily: "'DM Mono', monospace",
              }}
            >
              AI Coach
            </div>
            <div style={{ fontSize: 11, color: "#252840", fontFamily: "'DM Mono', monospace", marginTop: 2 }}>
              Analyse basée sur tes {closedCount} derniers trades
            </div>
          </div>
          <button
            onClick={runAI}
            disabled={aiLoading || closedCount < 3}
            style={{
              padding: "7px 16px",
              borderRadius: 9,
              border: `1px solid ${closedCount < 3 ? "#13162a" : "rgba(0,229,160,0.25)"}`,
              background:
                closedCount < 3
                  ? "transparent"
                  : aiLoading
                  ? "transparent"
                  : "rgba(0,229,160,0.05)",
              color:
                closedCount < 3 ? "#252840" : aiLoading ? "#3a4060" : "#00e5a0",
              cursor: closedCount < 3 ? "not-allowed" : "pointer",
              fontSize: 11,
              fontFamily: "'DM Mono', monospace",
              letterSpacing: "0.06em",
              transition: "all 0.2s",
            }}
          >
            {aiLoading ? "Analyse en cours…" : "Analyser →"}
          </button>
        </div>

        {aiError && (
          <div
            style={{
              background: "rgba(255,77,109,0.07)",
              border: "1px solid rgba(255,77,109,0.18)",
              padding: "10px 13px",
              borderRadius: 10,
              color: "#ff4d6d",
              fontSize: 13,
              lineHeight: 1.5,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            {aiError}
          </div>
        )}

        {aiLoading && (
          <div
            className="pulse"
            style={{
              color: "#252840",
              fontSize: 13,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            L'IA analyse tes trades…
          </div>
        )}

        {aiInsight && !aiLoading && (
          <div
            style={{
              fontSize: 14,
              color: "#9099c0",
              lineHeight: 1.75,
              borderLeft: "2px solid rgba(0,229,160,0.3)",
              paddingLeft: 16,
              whiteSpace: "pre-wrap",
            }}
          >
            {aiInsight}
          </div>
        )}

        {!aiInsight && !aiLoading && !aiError && (
          <div
            style={{
              color: "#1e2235",
              fontSize: 13,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            {closedCount < 3
              ? "Ajoute au moins 3 trades fermés pour activer l'IA."
              : "Clique sur Analyser pour obtenir un coaching personnalisé."}
          </div>
        )}
      </div>
    </div>
  );
};
