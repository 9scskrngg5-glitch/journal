import { useState, useMemo } from "react";
import { TradeForm } from "./TradeForm";
import { TradeRow } from "./TradeRow";

const modalOverlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.6)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: 16,
  zIndex: 50,
  backdropFilter: "blur(4px)",
};

/**
 * @param {{
 *   trades: import('../types').Trade[],
 *   pairs: string[],
 *   onAdd: (form: any) => Promise<{error:string|null}>,
 *   onSave: (id: string, form: any) => Promise<{error:string|null}>,
 *   onDelete: (id: string) => void,
 *   emptyForm: Record<string,string>,
 * }} props
 */
export const TradesTab = ({ trades, pairs, onAdd, onSave, onDelete, emptyForm }) => {
  const [showForm, setShowForm] = useState(false);
  const [filterPair, setFilterPair] = useState("ALL");
  const [editTrade, setEditTrade] = useState(null); // Trade | null

  const filtered = useMemo(
    () =>
      filterPair === "ALL" ? trades : trades.filter((t) => t.pair === filterPair),
    [trades, filterPair]
  );

  const handleAdd = async (form) => {
    const result = await onAdd(form);
    if (!result.error) setShowForm(false);
    return result;
  };

  const handleSave = async (form) => {
    const result = await onSave(editTrade.id, form);
    if (!result.error) setEditTrade(null);
    return result;
  };

  const editInitial = editTrade
    ? {
        pair: editTrade.pair || "",
        session: editTrade.session || "",
        entry: editTrade.entry == null ? "" : String(editTrade.entry),
        sl: editTrade.sl == null ? "" : String(editTrade.sl),
        tp: editTrade.tp == null ? "" : String(editTrade.tp),
        result: editTrade.result == null || editTrade.result === "" ? "" : String(editTrade.result),
        rr: editTrade.rr == null ? "" : String(editTrade.rr),
        emotion: editTrade.emotion || "",
        setup: editTrade.setup || "",
        confidence: editTrade.confidence == null || editTrade.confidence === "" ? "" : String(editTrade.confidence),
      }
    : null;

  const btnBase = {
    padding: "5px 12px",
    borderRadius: 7,
    border: "1px solid",
    cursor: "pointer",
    fontSize: 11,
    fontFamily: "'DM Mono', monospace",
    transition: "all 0.15s",
  };

  return (
    <div className="fade-in">
      {/* Toolbar */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 16,
          gap: 10,
          flexWrap: "wrap",
        }}
      >
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {pairs.map((p) => (
            <button
              key={p}
              onClick={() => setFilterPair(p)}
              style={{
                ...btnBase,
                borderColor: filterPair === p ? "#00e5a0" : "#181b2e",
                background: filterPair === p ? "rgba(0,229,160,0.07)" : "transparent",
                color: filterPair === p ? "#00e5a0" : "#3a4060",
              }}
            >
              {p}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowForm((s) => !s)}
          style={{
            padding: "8px 18px",
            borderRadius: 9,
            border: "none",
            background: showForm ? "#13162a" : "#00e5a0",
            color: showForm ? "#4a5070" : "#000",
            cursor: "pointer",
            fontSize: 12,
            fontWeight: 800,
            fontFamily: "'DM Mono', monospace",
            transition: "all 0.2s",
          }}
        >
          {showForm ? "Annuler" : "+ Nouveau trade"}
        </button>
      </div>

      {/* Add form */}
      {showForm && (
        <div
          className="fade-in"
          style={{
            background: "#0a0d18",
            border: "1px solid #181b2e",
            borderRadius: 16,
            padding: 22,
            marginBottom: 16,
          }}
        >
          <TradeForm
            initialValues={emptyForm}
            onSubmit={handleAdd}
            submitLabel="Valider →"
          />
        </div>
      )}

      {/* Trade list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {filtered.length === 0 && (
          <div
            style={{
              color: "#1e2235",
              textAlign: "center",
              padding: 50,
              fontSize: 13,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            Aucun trade enregistré
          </div>
        )}
        {filtered.map((t) => (
          <TradeRow
            key={t.id}
            trade={t}
            onClick={() => setEditTrade(t)}
            onDelete={() => onDelete(t.id)}
          />
        ))}
      </div>

      {/* Edit modal */}
      {editTrade && editInitial && (
        <div
          style={modalOverlay}
          onClick={() => setEditTrade(null)}
        >
          <div
            style={{
              width: "min(740px, 95vw)",
              background: "#0a0d18",
              border: "1px solid #181b2e",
              borderRadius: 18,
              padding: 22,
              boxShadow: "0 20px 60px rgba(0,0,0,0.5)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              style={{
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "space-between",
                marginBottom: 18,
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: 10,
                    color: "#3a4060",
                    letterSpacing: "0.12em",
                    textTransform: "uppercase",
                    fontFamily: "'DM Mono', monospace",
                  }}
                >
                  Modifier un trade
                </div>
                <div
                  style={{
                    fontSize: 18,
                    fontWeight: 800,
                    marginTop: 3,
                    fontFamily: "'Syne', sans-serif",
                    color: "#dde1f5",
                  }}
                >
                  {editTrade.pair || "Trade"}
                </div>
              </div>
              <button
                onClick={() => setEditTrade(null)}
                style={{
                  background: "transparent",
                  border: "1px solid #181b2e",
                  borderRadius: 9,
                  padding: "6px 11px",
                  color: "#4a5070",
                  cursor: "pointer",
                  fontSize: 12,
                  fontFamily: "'DM Mono', monospace",
                  transition: "border-color 0.2s",
                }}
              >
                ✕
              </button>
            </div>
            <TradeForm
              initialValues={editInitial}
              onSubmit={handleSave}
              onCancel={() => setEditTrade(null)}
              submitLabel="Sauvegarder →"
            />
          </div>
        </div>
      )}
    </div>
  );
};
