import { useState } from "react";

/**
 * @param {{ label: string, value: string|number, sub?: string, color?: string }} props
 */
export const StatCard = ({ label, value, sub, color }) => {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered
          ? "linear-gradient(135deg, #13172a 0%, #0f1220 100%)"
          : "linear-gradient(135deg, #0e1120 0%, #0a0d18 100%)",
        border: `1px solid ${hovered ? "#2a2f4a" : "#181b2e"}`,
        borderRadius: 16,
        padding: "18px 22px",
        display: "flex",
        flexDirection: "column",
        gap: 5,
        transition: "all 0.2s ease",
        transform: hovered ? "translateY(-1px)" : "none",
        cursor: "default",
      }}
    >
      <span
        style={{
          fontSize: 10,
          color: "#3a4060",
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          fontFamily: "'DM Mono', monospace",
          fontWeight: 500,
        }}
      >
        {label}
      </span>
      <span
        style={{
          fontSize: 21,
          fontWeight: 700,
          color: color || "#dde1f5",
          fontFamily: "'Syne', sans-serif",
          lineHeight: 1.1,
          letterSpacing: "-0.01em",
        }}
      >
        {value}
      </span>
      {sub && (
        <span style={{ fontSize: 11, color: "#2d3352", fontFamily: "'DM Mono', monospace" }}>
          {sub}
        </span>
      )}
    </div>
  );
};
