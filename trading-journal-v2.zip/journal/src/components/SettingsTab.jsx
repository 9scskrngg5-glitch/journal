import { useState } from "react";

const btnStyle = (variant = "default") => ({
  padding: "10px 16px",
  borderRadius: 10,
  cursor: "pointer",
  fontSize: 13,
  fontWeight: 700,
  fontFamily: "'DM Mono', monospace",
  transition: "all 0.2s",
  ...(variant === "danger"
    ? { border: "1px solid rgba(255,77,109,0.25)", background: "transparent", color: "#ff4d6d" }
    : variant === "primary"
    ? { border: "none", background: "#00e5a0", color: "#000" }
    : { border: "1px solid #181b2e", background: "#0d1020", color: "#9099c0" }),
});

/**
 * @param {{
 *   trades: import('../types').Trade[],
 *   tasks: import('../types').Task[],
 *   onImport: (payload: any) => Promise<{error:string|null, tasks?: any[]}>,
 *   onReset: () => void,
 * }} props
 */
export const SettingsTab = ({ trades, tasks, onImport, onReset }) => {
  const [importText, setImportText] = useState("");
  const [importError, setImportError] = useState("");
  const [importSuccess, setImportSuccess] = useState(false);

  const handleExport = () => {
    const payload = { trades, tasks, version: 1, exportedAt: Date.now() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `trading-journal-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReset = async () => {
    if (!window.confirm("Supprimer tous les trades et tâches ?")) return;
    onReset();
    setImportText("");
    setImportError("");
  };

  const handleImport = async () => {
    setImportError("");
    setImportSuccess(false);
    try {
      const parsed = JSON.parse(importText || "{}");
      const result = await onImport(parsed);
      if (result.error) {
        setImportError(result.error);
      } else {
        setImportText("");
        setImportSuccess(true);
        setTimeout(() => setImportSuccess(false), 3000);
      }
    } catch {
      setImportError("JSON invalide. Vérifie le format.");
    }
  };

  return (
    <div className="fade-in">
      <div
        style={{
          background: "#0a0d18",
          border: "1px solid #181b2e",
          borderRadius: 16,
          padding: 22,
          marginBottom: 16,
        }}
      >
        <div
          style={{
            fontSize: 10,
            color: "#3a4060",
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            fontFamily: "'DM Mono', monospace",
            marginBottom: 16,
          }}
        >
          Backup & données
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
          <button style={btnStyle("default")} onClick={handleExport}>
            Export JSON ↓
          </button>
          <button style={btnStyle("danger")} onClick={handleReset}>
            Reset données
          </button>
        </div>

        <div
          style={{
            fontSize: 11,
            color: "#2d3352",
            fontFamily: "'DM Mono', monospace",
            marginBottom: 8,
          }}
        >
          Import JSON
        </div>
        <textarea
          value={importText}
          onChange={(e) => setImportText(e.target.value)}
          placeholder='{"trades":[...],"tasks":[...]}'
          style={{
            width: "100%",
            minHeight: 120,
            background: "#080a14",
            border: "1px solid #181b2e",
            color: "#dde1f5",
            borderRadius: 11,
            padding: "10px 13px",
            fontSize: 12,
            fontFamily: "'DM Mono', monospace",
            outline: "none",
            resize: "vertical",
            transition: "border-color 0.2s",
          }}
          onFocus={(e) => (e.target.style.borderColor = "#00e5a0")}
          onBlur={(e) => (e.target.style.borderColor = "#181b2e")}
        />

        {importError && (
          <div
            style={{
              marginTop: 10,
              background: "rgba(255,77,109,0.07)",
              border: "1px solid rgba(255,77,109,0.18)",
              padding: "10px 13px",
              borderRadius: 10,
              color: "#ff4d6d",
              fontSize: 13,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            {importError}
          </div>
        )}

        {importSuccess && (
          <div
            style={{
              marginTop: 10,
              background: "rgba(0,229,160,0.07)",
              border: "1px solid rgba(0,229,160,0.18)",
              padding: "10px 13px",
              borderRadius: 10,
              color: "#00e5a0",
              fontSize: 13,
              fontFamily: "'DM Mono', monospace",
            }}
          >
            Import réussi ✓
          </div>
        )}

        <div
          style={{
            display: "flex",
            gap: 10,
            marginTop: 14,
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: "#1e2235",
              fontFamily: "'DM Mono', monospace",
            }}
          >
            {trades.length} trades · {tasks.length} tâches
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={() => { setImportText(""); setImportError(""); }}
              style={btnStyle("default")}
            >
              Annuler
            </button>
            <button onClick={handleImport} style={btnStyle("primary")}>
              Importer →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
