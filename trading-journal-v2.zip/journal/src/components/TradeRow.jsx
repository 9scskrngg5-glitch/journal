import { pnlColor, formatTs } from "../lib/trading";

/**
 * @param {{
 *   trade: import('../types').Trade,
 *   onClick: () => void,
 *   onDelete: () => void,
 * }} props
 */
export const TradeRow = ({ trade: t, onClick, onDelete }) => {
  return (
    <div
      onClick={onClick}
      style={{
        background: "#0a0d18",
        border: "1px solid #13162a",
        borderLeft: `3px solid ${t.result !== "" ? pnlColor(t.result) : "#1a1d2e"}`,
        borderRadius: 12,
        padding: "13px 18px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        cursor: "pointer",
        transition: "border-color 0.2s, background 0.2s",
      }}
      onMouseEnter={(e) => (e.currentTarget.style.background = "#0d1020")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "#0a0d18")}
    >
      {/* Left side */}
      <div style={{ display: "flex", gap: 22, alignItems: "center", flexWrap: "wrap" }}>
        {/* Pair + session */}
        <div style={{ minWidth: 80 }}>
          <div style={{ fontSize: 13, fontWeight: 700, fontFamily: "'Syne', sans-serif", color: "#dde1f5" }}>
            {t.pair}
          </div>
          <div style={{ fontSize: 10, color: "#2d3352", fontFamily: "'DM Mono', monospace", marginTop: 2 }}>
            {t.session}
          </div>
          {t.createdAt && (
            <div style={{ fontSize: 10, color: "#252840", fontFamily: "'DM Mono', monospace", marginTop: 1 }}>
              {formatTs(t.createdAt)}
            </div>
          )}
        </div>

        {/* Entry / SL / TP */}
        <div style={{ fontSize: 11, color: "#3a4060", fontFamily: "'DM Mono', monospace", lineHeight: 1.6 }}>
          <div>Entry <span style={{ color: "#4a5480" }}>{t.entry}</span></div>
          <div>SL <span style={{ color: "#4a5480" }}>{t.sl}</span> / TP <span style={{ color: "#4a5480" }}>{t.tp}</span></div>
        </div>

        {/* R/R */}
        {t.rr && (
          <div
            style={{
              fontSize: 11,
              fontFamily: "'DM Mono', monospace",
              color: "#00e5a0",
              background: "rgba(0,229,160,0.06)",
              border: "1px solid rgba(0,229,160,0.12)",
              padding: "2px 8px",
              borderRadius: 6,
            }}
          >
            R/R {t.rr}
          </div>
        )}

        {/* Setup / emotion */}
        {(t.setup || t.emotion || t.confidence) && (
          <div style={{ fontSize: 11, color: "#3a4060", fontFamily: "'DM Mono', monospace", lineHeight: 1.6 }}>
            {t.setup && <div>{t.setup}</div>}
            {t.emotion && (
              <div style={{ color: (t.emotion || "").toLowerCase() === "revenge" ? "#ff4d6d" : "#3a4060" }}>
                {t.emotion}
                {t.confidence ? ` · ${t.confidence}/10` : ""}
              </div>
            )}
          </div>
        )}

        {/* Flags */}
        {t.flags?.length > 0 && (
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {t.flags.map((f) => (
              <span
                key={f}
                style={{
                  fontSize: 10,
                  padding: "2px 7px",
                  borderRadius: 5,
                  background: "rgba(255,77,109,0.08)",
                  color: "#ff4d6d",
                  border: "1px solid rgba(255,77,109,0.18)",
                  fontFamily: "'DM Mono', monospace",
                }}
              >
                ⚠ {f}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Right side */}
      <div style={{ display: "flex", gap: 14, alignItems: "center", flexShrink: 0 }}>
        {t.result !== "" && (
          <span
            style={{
              fontSize: 15,
              fontWeight: 700,
              fontFamily: "'Syne', sans-serif",
              color: pnlColor(t.result),
            }}
          >
            {Number(t.result) > 0 ? "+" : ""}
            {t.result}$
          </span>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          style={{
            background: "none",
            border: "none",
            color: "#252840",
            cursor: "pointer",
            fontSize: 14,
            padding: "2px 6px",
            borderRadius: 4,
            transition: "color 0.2s",
          }}
          onMouseOver={(e) => (e.target.style.color = "#ff4d6d")}
          onMouseOut={(e) => (e.target.style.color = "#252840")}
        >
          ✕
        </button>
      </div>
    </div>
  );
};
