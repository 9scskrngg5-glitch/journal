import { useEffect, useState } from "react";
import { calcRR } from "../lib/trading";

const FIELDS = [
  { k: "pair",       label: "Pair",              ph: "BTC/USD",             type: "text"   },
  { k: "session",    label: "Session",            ph: "New York",            type: "text"   },
  { k: "entry",      label: "Entrée",             ph: "104500",              type: "number" },
  { k: "sl",         label: "Stop Loss",          ph: "104000",              type: "number" },
  { k: "tp",         label: "Take Profit",        ph: "105500",              type: "number" },
  { k: "result",     label: "Résultat ($)",       ph: "+120 ou vide",        type: "number" },
  { k: "setup",      label: "Setup",              ph: "Break of structure",  type: "text"   },
  { k: "emotion",    label: "Émotion",            ph: "calme / revenge…",    type: "text"   },
  { k: "confidence", label: "Confiance (1–10)",   ph: "7",                   type: "number" },
];

const inputStyle = {
  background: "#0a0d18",
  border: "1px solid #181b2e",
  color: "#dde1f5",
  padding: "9px 13px",
  borderRadius: 10,
  width: "100%",
  fontSize: 13,
  fontFamily: "'DM Mono', monospace",
  transition: "border-color 0.2s",
  outline: "none",
};

/**
 * @param {{
 *   initialValues: Record<string,string>,
 *   onSubmit: (form: Record<string,string>) => Promise<{error:string|null}>,
 *   onCancel?: () => void,
 *   submitLabel?: string,
 *   title?: string,
 * }} props
 */
export const TradeForm = ({ initialValues, onSubmit, onCancel, submitLabel = "Valider →", title }) => {
  const [form, setForm] = useState(initialValues);
  const [error, setError] = useState("");

  // Auto RR
  useEffect(() => {
    if (form.entry && form.sl && form.tp) {
      const rr = calcRR(Number(form.entry), Number(form.sl), Number(form.tp));
      setForm((f) => ({ ...f, rr }));
    }
  }, [form.entry, form.sl, form.tp]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    setError("");
    const { error } = await onSubmit(form);
    if (error) setError(error);
  };

  return (
    <div>
      {title && (
        <div
          style={{
            fontSize: 11,
            color: "#3a4060",
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            fontFamily: "'DM Mono', monospace",
            marginBottom: 14,
          }}
        >
          {title}
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {FIELDS.map(({ k, label, ph, type }) => (
          <div key={k}>
            <label
              style={{
                fontSize: 11,
                color: "#2d3352",
                display: "block",
                marginBottom: 4,
                fontFamily: "'DM Mono', monospace",
              }}
            >
              {label}
            </label>
            <input
              type={type}
              placeholder={ph}
              value={form[k] ?? ""}
              onChange={(e) => set(k, e.target.value)}
              style={inputStyle}
              onFocus={(e) => (e.target.style.borderColor = "#00e5a0")}
              onBlur={(e) => (e.target.style.borderColor = "#181b2e")}
            />
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginTop: 14,
        }}
      >
        <span
          style={{
            fontSize: 12,
            color: "#3a4060",
            fontFamily: "'DM Mono', monospace",
          }}
        >
          R/R:{" "}
          <span style={{ color: form.rr ? "#00e5a0" : "#2a3050", fontWeight: 700 }}>
            {form.rr || "—"}
          </span>
        </span>

        <div style={{ display: "flex", gap: 10 }}>
          {onCancel && (
            <button
              onClick={onCancel}
              style={{
                padding: "9px 14px",
                borderRadius: 10,
                border: "1px solid #181b2e",
                background: "transparent",
                color: "#4a5070",
                cursor: "pointer",
                fontSize: 13,
                fontFamily: "'DM Mono', monospace",
              }}
            >
              Annuler
            </button>
          )}
          <button
            onClick={handleSubmit}
            style={{
              padding: "9px 22px",
              borderRadius: 10,
              border: "none",
              background: "#00e5a0",
              color: "#000",
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 800,
              fontFamily: "'DM Mono', monospace",
              letterSpacing: "0.02em",
            }}
          >
            {submitLabel}
          </button>
        </div>
      </div>

      {error && (
        <div
          style={{
            marginTop: 12,
            background: "rgba(255,77,109,0.08)",
            border: "1px solid rgba(255,77,109,0.2)",
            padding: "10px 13px",
            borderRadius: 10,
            color: "#ff4d6d",
            fontSize: 13,
            lineHeight: 1.5,
            fontFamily: "'DM Mono', monospace",
          }}
        >
          {error}
        </div>
      )}
    </div>
  );
};
